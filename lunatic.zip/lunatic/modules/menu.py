from lunatic import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/LT-BACKEND/proxyvpn/main/statushariini"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("FEATUR SSH", "ssh")],
                    [Button.inline("FEATUR VMESS", "vmess-member"),
                     Button.inline("FEATUR VLESS", "vless-member")],
                    [Button.inline("FEATUR TROJAN", "trojan-member"),
                     Button.inline("FEATUR SDOWSK", "shadowsocks-member")],
                    [Button.inline("FEATUR NOBVPN", "noobzvpn-member")],
                    [Button.url("🛂Tele Group🛂", "https://t.me/LTTestimoniqu"),
                     Button.inline("🕊topup manual🕊", f"topup")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━**
 `🥀FEATURES LIBEV🥀`
**━━━━━━━━━━━━━━━━**
**━━━━━━━━━━━━━━━━**
**» SSH     :** `{get_ssh_status()}`
**» XRAY    :** `{get_xray_status()}`
**» UDP     :** `{get_udp_status()}`
**» NOBZ    :** `{get_noobz_status()}`
**» SLDNS   :** `{get_slowdns_status()}`
**» DROPBER :** `{get_dropbear_status()}`
**» WBSOKET :** `{get_ws_status()}`
**» ANTI DDS:** `{get_ddos_status()}`
**━━━━━━━━━━━━━━━━**
**» balance :** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline(" SSHOPNVPN ", "ssh")],
                    [Button.inline(" VMESS XRY ", "vmess"),
                     Button.inline(" VLESS XRY ", "vless")],
                    [Button.inline(" TROJAN XRY ", "trojan"),
                     Button.inline(" SADOWSOCK ", "shadowsocks")],
                    [Button.inline(" NOOBZVPNS ", "noobzvpns"),
                     Button.inline(" ADD MEMBERS", "registrasi-member"),
                     Button.inline(" DELT MEMBER ", "delete-member")],
                     [Button.inline(" LIST MEMBER ", "show-user")],
                    [Button.inline("💵 ADD SALDO 💵", "addsaldo")],
                    [Button.inline("👙 VPS INFO 👙", "info"),
                     Button.inline("⚔️SET LIBEV ⚔️", "setting")],
                    [Button.url("🌍WA GRUP🌍", "https://chat.whatsapp.com/GCYeQJsBu5JElcVZX2owQQ"),
                     Button.url("🇲🇨ORDER SCRIPT🇲🇨", "wa.me/6285955333616")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━**
 `🥀FEATURES LIBEV🥀`
**━━━━━━━━━━━━━━━━**
**━━━━━━━━━━━━━━━━**
**» SSH     :** `{get_ssh_status()}`
**» XRAY    :** `{get_xray_status()}`
**» UDP     :** `{get_udp_status()}`
**» NOBZ    :** `{get_noobz_status()}`
**» SLDNS   :** `{get_slowdns_status()}`
**» DROPBER :** `{get_dropbear_status()}`
**» WBSOKET :** `{get_ws_status()}`
**» ANTI DDS:** `{get_ddos_status()}`
**━━━━━━━━━━━━━━━━**
**» balance :** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━**
**» SSH    Rp.10.000 **
**» UDP    Rp.10.000 **
**» NOBVPN Rp.10.000 **
**» VMESS  Rp.10.000 **
**» VLESS  Rp.10.000 **
**» TROJAN Rp.10.000 **
**» SLDNS  Rp.10.000 **
**━━━━━━━━━━━━━━━━**
**» BALANCE :** `RP.{saldo_aji}`
**» USER    :** `{get_user_count()}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

